import { useRef, useState } from 'react'
import { Workflow, Terminal, GitBranch } from 'lucide-react'
import InputPanel from './components/InputPanel'
import DagCanvas from './components/DagCanvas'
import ResultsPanel from './components/ResultsPanel'
import { SCENARIOS, matchScenario } from './data/samples'
import { DAG_NODES } from './lib/dag'
import { runSkill, type RunOutput } from './lib/runner'
import type { NodeRunState, NodeStatus, RunScenario } from './lib/types'

function initStates(): Record<string, NodeRunState> {
  const s: Record<string, NodeRunState> = {}
  DAG_NODES.forEach((n) => (s[n.id] = { status: 'idle', logs: [] }))
  return s
}

export default function App() {
  const [nlInput, setNlInput] = useState('618快到了，帮我算一下大促备货量')
  const [scenario, setScenario] = useState<RunScenario>(SCENARIOS[1])
  const [autoCreate, setAutoCreate] = useState(false)
  const [running, setRunning] = useState(false)
  const [states, setStates] = useState<Record<string, NodeRunState>>(initStates())
  const [logs, setLogs] = useState<{ node: string; text: string }[]>([])
  const [output, setOutput] = useState<RunOutput | null>(null)
  const logEndRef = useRef<HTMLDivElement>(null)

  const nodeName = (id: string) => DAG_NODES.find((n) => n.id === id)?.display_name || id

  function pushLog(node: string, text: string) {
    setLogs((prev) => [...prev, { node, text }])
    setTimeout(() => logEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 30)
  }

  function setNodeStatus(nodeId: string, status: NodeStatus) {
    setStates((prev) => ({ ...prev, [nodeId]: { ...prev[nodeId], status } }))
  }

  async function handleRun() {
    if (running) return
    setRunning(true)
    setStates(initStates())
    setLogs([])
    setOutput(null)
    pushLog('system', `▶ 触发 Skill：${scenario.label}（${scenario.nlText}）`)

    const out = await runSkill(
      scenario,
      { autoCreatePurchaseOrder: autoCreate },
      {
        onNodeStatus: (id, status) => {
          setNodeStatus(id, status)
          if (status === 'running') pushLog(id, `● 开始执行：${nodeName(id)}`)
          if (status === 'skipped') pushLog(id, `○ 跳过：${nodeName(id)}`)
        },
        onNodeLog: (id, log) => pushLog(id, log),
        onNodeDone: (id, dur) =>
          setStates((prev) => ({ ...prev, [id]: { ...prev[id], durationMs: dur } })),
      },
      1,
    )
    setOutput(out)
    pushLog('system', `✔ 工作流执行完成，共 ${out.stats.totalSku} 个SKU`)
    setRunning(false)
  }

  function handleSubmitNl() {
    const matched = matchScenario(nlInput)
    setScenario(matched)
  }

  return (
    <div className="h-screen flex flex-col bg-slate-100">
      {/* Header */}
      <header className="flex items-center gap-3 border-b border-slate-200 bg-white px-5 py-3">
        <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-brand-600 text-white">
          <Workflow className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-[15px] font-bold text-slate-800">SKU补货量计算与自动建单 · Agent Skill 演示</h1>
          <p className="text-[11px] text-slate-500">
            自然语言驱动 · DAG工作流编排 · 供应商产能回告 · 异常拦截 · 端到端建单闭环
          </p>
        </div>
        <div className="ml-auto flex items-center gap-1.5 text-[11px] text-slate-400">
          <GitBranch className="w-3.5 h-3.5" />
          {DAG_NODES.length} 节点 DAG · 逻辑忠实移植自 Python skill
        </div>
      </header>

      {/* 三栏 */}
      <div className="flex-1 grid grid-cols-[320px_1fr_400px] gap-3 p-3 overflow-hidden">
        {/* 左：输入 */}
        <div className="rounded-2xl bg-white border border-slate-200 p-4 overflow-auto">
          <InputPanel
            nlInput={nlInput}
            setNlInput={setNlInput}
            scenario={scenario}
            onSelectScenario={setScenario}
            onSubmitNl={handleSubmitNl}
            autoCreate={autoCreate}
            setAutoCreate={setAutoCreate}
            running={running}
            onRun={handleRun}
          />
        </div>

        {/* 中：DAG + 日志 */}
        <div className="flex flex-col gap-3 overflow-hidden">
          <div className="flex-1 rounded-2xl bg-white border border-slate-200 p-4 overflow-auto">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2">
              <Workflow className="w-4 h-4 text-brand-600" />
              DAG 工作流执行
              <span className="ml-2 text-[11px] font-normal text-slate-400">
                蓝色高亮=执行中 · 绿=完成 · 黄=命中异常/审核 · 虚线=条件跳过
              </span>
            </div>
            <DagCanvas states={states} />
          </div>
          {/* 日志控制台 */}
          <div className="h-44 rounded-2xl bg-slate-900 border border-slate-800 p-3 overflow-auto">
            <div className="flex items-center gap-2 text-[11px] font-semibold text-slate-300 mb-1.5">
              <Terminal className="w-3.5 h-3.5" />
              执行日志
            </div>
            <div className="font-mono text-[11px] leading-relaxed space-y-0.5">
              {logs.length === 0 && (
                <div className="text-slate-500">等待运行…点击左下角「运行补货 Skill」</div>
              )}
              {logs.map((l, i) => (
                <div key={i} className="text-slate-300 animate-fade-in">
                  <span className="text-slate-500">
                    [{l.node === 'system' ? 'system' : nodeName(l.node)}]
                  </span>{' '}
                  {l.text}
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          </div>
        </div>

        {/* 右：结果 */}
        <div className="rounded-2xl bg-white border border-slate-200 p-4 overflow-hidden">
          <ResultsPanel output={output} running={running} />
        </div>
      </div>
    </div>
  )
}
