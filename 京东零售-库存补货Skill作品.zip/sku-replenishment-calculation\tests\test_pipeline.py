#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
端到端链路测试

用 templates/补货计算数据样例.csv 跑通「解析 -> 计算 -> 异常汇总」,
同时校验样例数据确实覆盖了每一类异常分支。

依赖: pandas(解析)、openpyxl(仅建单模板导出,缺失时自动跳过对应用例)
运行: python3 tests/test_pipeline.py
"""

import os
import sys
import tempfile
import unittest
from datetime import datetime

SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(SKILL_ROOT, 'scripts'))

from calculate_replenishment import ReplenishmentCalculator  # noqa: E402
from excel_processor import ExcelProcessor  # noqa: E402

SAMPLE_FILE = os.path.join(SKILL_ROOT, 'templates', '补货计算数据样例.csv')
CONFIG_DIR = os.path.join(SKILL_ROOT, 'config')
# 固定基准日,避开大促窗口,保证断言稳定
NORMAL_DATE = datetime(2026, 1, 15)

try:
    import openpyxl  # noqa: F401
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


class TestSampleFileParsing(unittest.TestCase):
    """样例文件解析"""

    @classmethod
    def setUpClass(cls):
        cls.processor = ExcelProcessor()

    def test_sample_file_exists(self):
        self.assertTrue(os.path.exists(SAMPLE_FILE), f"样例文件缺失: {SAMPLE_FILE}")

    def test_validation_passes(self):
        validation = self.processor.validate_excel_format(SAMPLE_FILE)
        self.assertTrue(validation['valid'], f"校验失败: {validation['errors']}")
        self.assertEqual(validation['sku_count'], 7)

    def test_supplier_column_present(self):
        # 样例含供应商编号列,不应触发产能约束失效的警告
        validation = self.processor.validate_excel_format(SAMPLE_FILE)
        self.assertFalse(
            any('供应商编号' in w for w in validation['warnings']),
            f"意外的供应商警告: {validation['warnings']}"
        )

    def test_rain_without_14d_is_warned(self):
        # SKU007 标记雨天但未填14日销量,应提前预警
        validation = self.processor.validate_excel_format(SAMPLE_FILE)
        self.assertTrue(
            any('14日销量' in w for w in validation['warnings']),
            f"未检出雨天缺数据警告: {validation['warnings']}"
        )

    def test_parse_preserves_none_for_missing_14d(self):
        sku_list = self.processor.parse_upload_excel(SAMPLE_FILE)
        by_id = {sku['sku_id']: sku for sku in sku_list}

        # SKU003 填了14日销量
        self.assertEqual(by_id['SKU003']['sales_14d'], 210.0)
        self.assertTrue(by_id['SKU003']['has_rain'])
        # SKU001 未填,必须是None而非0,否则雨天分支会静默算错
        self.assertIsNone(by_id['SKU001']['sales_14d'])
        self.assertFalse(by_id['SKU001']['has_rain'])

    def test_parse_reads_supplier_id(self):
        sku_list = self.processor.parse_upload_excel(SAMPLE_FILE)
        by_id = {sku['sku_id']: sku for sku in sku_list}
        self.assertEqual(by_id['SKU004']['supplier_id'], 'S10001')

    def test_unsupported_extension_rejected(self):
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as handle:
            temp_path = handle.name
        try:
            with self.assertRaises(ValueError):
                self.processor.parse_upload_excel(temp_path)
        finally:
            os.unlink(temp_path)


class TestEndToEndPipeline(unittest.TestCase):
    """解析 -> 计算 -> 汇总 全链路"""

    @classmethod
    def setUpClass(cls):
        processor = ExcelProcessor()
        cls.calculator = ReplenishmentCalculator(CONFIG_DIR)
        cls.sku_list = processor.parse_upload_excel(SAMPLE_FILE)
        cls.results = cls.calculator.batch_calculate(cls.sku_list, NORMAL_DATE)
        cls.by_id = {r['sku_id']: r for r in cls.results}
        cls.summary = cls.calculator.check_anomalies(cls.results)

    def test_normal_sku_quantity(self):
        # 35天 × 日均10件 - 可订购70件 = 280件
        self.assertEqual(self.by_id['SKU001']['replenishment_qty'], 280)
        self.assertFalse(self.by_id['SKU001']['need_manual_review'])

    def test_long_age_sku_intercepted(self):
        result = self.by_id['SKU002']
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('长库龄' in w for w in result['warnings']))

    def test_rain_sku_uses_14d(self):
        # 雨天改用14日销量: 35 × 15 - 120 = 405件
        result = self.by_id['SKU003']
        self.assertEqual(result['replenishment_qty'], 405)
        self.assertFalse(result['need_manual_review'])

    def test_sku_without_capacity_feedback(self):
        # CSV不含产能回告(需调API获取),此处应按无约束处理但给出提示
        result = self.by_id['SKU004']
        self.assertEqual(result['replenishment_qty'], 1650)
        self.assertTrue(any('暂无产能回告' in w for w in result['warnings']))

    def test_zero_sales_sku_intercepted(self):
        result = self.by_id['SKU005']
        self.assertTrue(result['need_manual_review'])
        self.assertEqual(result['replenishment_qty'], 0)

    def test_large_order_sku_intercepted(self):
        # 3500件 × 400元 = 140万,超过100万阈值
        result = self.by_id['SKU006']
        self.assertEqual(result['replenishment_qty'], 3500)
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('大额订单' in w for w in result['warnings']))

    def test_rain_sku_missing_14d_intercepted(self):
        result = self.by_id['SKU007']
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('计算异常' in w for w in result['warnings']))

    def test_summary_matches_expectation(self):
        # 4个转人工: 长库龄/零销量/大额/雨天缺数据; 3个可自动建单
        self.assertEqual(self.summary['total_sku'], 7)
        self.assertEqual(self.summary['need_review_count'], 4)
        self.assertEqual(self.summary['auto_order_count'], 3)
        self.assertCountEqual(
            self.summary['review_sku_ids'],
            ['SKU002', 'SKU005', 'SKU006', 'SKU007']
        )

    def test_sample_covers_every_anomaly_category(self):
        # 样例数据应触发全部关键异常分类,保证演示覆盖面
        categories = self.summary['categories']
        for category in ('large_order', 'long_inventory_age', 'zero_sales',
                         'capacity_unknown', 'calculation_error'):
            self.assertTrue(
                categories[category],
                f"样例数据未覆盖异常分类: {category}"
            )

    def test_capacity_constraint_after_merge(self):
        # 模拟产能查询API回告,验证封顶生效
        capacity_list = [{
            'skuId': 'SKU004', 'supplierId': 'S10001',
            'maxSupplyQty': 500, 'leadTimeDays': 7, 'capacityStatus': 'limited'
        }]
        merged = self.calculator.merge_capacity_data(
            [dict(sku) for sku in self.sku_list], capacity_list
        )
        results = self.calculator.batch_calculate(merged, NORMAL_DATE)
        sku004 = next(r for r in results if r['sku_id'] == 'SKU004')

        self.assertEqual(sku004['suggested_qty'], 1650)
        self.assertEqual(sku004['replenishment_qty'], 500)
        self.assertTrue(sku004['need_manual_review'])


class TestTableBuilding(unittest.TestCase):
    """输出表格构建(与文件IO分离,不需要openpyxl)"""

    @classmethod
    def setUpClass(cls):
        processor = ExcelProcessor()
        cls.processor = processor
        cls.calculator = ReplenishmentCalculator(CONFIG_DIR)
        sku_list = processor.parse_upload_excel(SAMPLE_FILE)
        cls.results = cls.calculator.batch_calculate(sku_list, NORMAL_DATE)

    def test_purchase_table_excludes_review_skus(self):
        # 仅3个可自动建单的SKU进入模板
        df = self.processor.build_purchase_table(self.results)
        self.assertEqual(len(df), 3)
        self.assertCountEqual(df['SKU ID'].tolist(), ['SKU001', 'SKU003', 'SKU004'])

    def test_purchase_table_column_order(self):
        df = self.processor.build_purchase_table(self.results)
        self.assertEqual(list(df.columns), ExcelProcessor.PURCHASE_TEMPLATE_COLUMNS)

    def test_empty_results_keep_headers(self):
        # 无可建单SKU时仍须输出合法表头,否则建单接口解析会失败
        df = self.processor.build_purchase_table([])
        self.assertEqual(len(df), 0)
        self.assertEqual(list(df.columns), ExcelProcessor.PURCHASE_TEMPLATE_COLUMNS)

    def test_unsupported_template_type(self):
        with self.assertRaises(NotImplementedError):
            self.processor.build_purchase_table(self.results, template_type='ECLP')

    def test_result_table_flattens_lists(self):
        df = self.calculator.build_result_table(self.results)
        self.assertEqual(len(df), 7)
        # 列表字段应展平为文本,不能出现Python列表字面量
        for value in df['异常提示'].dropna():
            self.assertNotIn('[', str(value))

    def test_result_table_boolean_to_chinese(self):
        df = self.calculator.build_result_table(self.results)
        self.assertTrue(set(df['需人工审核'].unique()) <= {'是', '否'})

    def test_result_table_uses_chinese_headers(self):
        df = self.calculator.build_result_table(self.results)
        for header in ('SKU ID', '补货数量', '日均销量', '异常提示'):
            self.assertIn(header, df.columns)


@unittest.skipUnless(HAS_OPENPYXL, '需要 openpyxl 才能写Excel文件')
class TestExcelFileOutput(unittest.TestCase):
    """Excel文件写入(依赖openpyxl)"""

    @classmethod
    def setUpClass(cls):
        processor = ExcelProcessor()
        cls.processor = processor
        cls.calculator = ReplenishmentCalculator(CONFIG_DIR)
        sku_list = processor.parse_upload_excel(SAMPLE_FILE)
        cls.results = cls.calculator.batch_calculate(sku_list, NORMAL_DATE)

    def test_purchase_template_written(self):
        import pandas as pd

        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = os.path.join(temp_dir, 'purchase_template.xlsx')
            self.processor.generate_purchase_template(self.results, output_path)

            self.assertTrue(os.path.exists(output_path))
            df = pd.read_excel(output_path)
            self.assertEqual(len(df), 3)

    def test_result_export_written(self):
        import pandas as pd

        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = os.path.join(temp_dir, 'result.xlsx')
            self.calculator.export_to_excel(self.results, output_path)

            self.assertTrue(os.path.exists(output_path))
            df = pd.read_excel(output_path)
            self.assertEqual(len(df), 7)
            self.assertIn('需人工审核', df.columns)


if __name__ == '__main__':
    unittest.main(verbosity=2)
