// 类型定义：与 Python skill 的数据结构保持一致

export interface SkuData {
  sku_id: string
  sales_28d: number
  sales_7d: number
  sales_14d?: number
  current_stock: number
  in_transit_stock: number
  unit_price?: number
  inventory_age?: number
  has_rain?: boolean
  supplier_id?: string
  // 由产能查询节点合并写入
  max_supply_qty?: number | null
  capacity_status?: 'normal' | 'limited' | 'unavailable'
  lead_time_days?: number
}

export interface ReplenishmentResult {
  sku_id: string
  replenishment_qty: number
  suggested_qty: number
  supplier_max_supply: number | null
  daily_sales: number
  target_turnover_days: number
  orderable_stock: number
  warnings: string[]
  need_manual_review: boolean
  calculation_notes: string[]
}

export interface SkillConfig {
  targetTurnoverDays: number
  salesWeight28Days: number
  salesWeight7Days: number
  largeOrderThreshold: number
  longAgeThreshold: number
  enableCapacityConstraint: boolean
}

export interface CapacityRecord {
  skuId: string
  supplierId: string
  maxSupplyQty: number
  leadTimeDays: number
  capacityStatus: 'normal' | 'limited' | 'unavailable'
}

// DAG 节点类型（镜像 manifest.json）
export type NodeType = 'code_interpreter' | 'api_call' | 'tool_call'
export type NodeStatus = 'idle' | 'running' | 'success' | 'skipped' | 'warning'

export interface DagNode {
  id: string
  type: NodeType
  display_name: string
  depends_on: string[]
  condition?: string
  detail: string // 该节点调用的脚本/接口/工具
}

export interface DagEdge {
  from: string
  to: string
}

export interface NodeRunState {
  status: NodeStatus
  durationMs?: number
  logs: string[]
}

export interface RunScenario {
  id: string
  label: string
  nlText: string // 模拟的自然语言输入
  description: string
  simulatedDate: string // 模拟"当前日期"，用于大促判断 YYYY-MM-DD
  configOverride: Partial<SkillConfig>
  skus: SkuData[]
}
