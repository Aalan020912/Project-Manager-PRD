// skill 核心逻辑：忠实移植自 scripts/calculate_replenishment.py
import type {
  SkuData,
  ReplenishmentResult,
  SkillConfig,
  CapacityRecord,
} from './types'

export const DEFAULT_CONFIG: SkillConfig = {
  targetTurnoverDays: 35,
  salesWeight28Days: 0.5,
  salesWeight7Days: 0.5,
  largeOrderThreshold: 1000000,
  longAgeThreshold: 90,
  enableCapacityConstraint: true,
}

const PROMOTION_DATES = [
  { month: 5, day: 30, name: '618大促' },
  { month: 10, day: 30, name: '双11大促' },
]

// ---- 计算日均销量（对应 calculate_daily_sales）----
export function calculateDailySales(
  sku: SkuData,
  config: SkillConfig,
): { dailySales: number; note: string } {
  if (sku.has_rain) {
    if (sku.sales_14d == null) {
      throw new Error('雨天场景需要提供14日销量数据')
    }
    return { dailySales: sku.sales_14d / 14, note: '雨天场景:使用14日销量' }
  }
  const w28 = config.salesWeight28Days
  const w7 = config.salesWeight7Days
  if (Math.abs(w28 + w7 - 1.0) > 0.01) {
    throw new Error(`权重之和必须为1,当前: ${w28 + w7}`)
  }
  const daily28 = sku.sales_28d > 0 ? sku.sales_28d / 28 : 0
  const daily7 = sku.sales_7d > 0 ? sku.sales_7d / 7 : 0
  const dailySales = daily28 * w28 + daily7 * w7
  return { dailySales, note: `正常场景:28日权重=${w28},7日权重=${w7}` }
}

// ---- 目标周转天数（对应 get_target_turnover_days）----
export function getTargetTurnoverDays(
  config: SkillConfig,
  currentDate: Date,
): { targetDays: number; note: string } {
  for (const promo of PROMOTION_DATES) {
    const promoDate = new Date(currentDate.getFullYear(), promo.month - 1, promo.day)
    const daysToPromo = Math.round(
      (promoDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24),
    )
    if (daysToPromo >= 0 && daysToPromo <= 45) {
      return { targetDays: 45, note: `${promo.name}前${daysToPromo}天,调整为45天` }
    }
  }
  return { targetDays: config.targetTurnoverDays, note: '正常周期,默认35天' }
}

// ---- 产能约束（对应 apply_capacity_constraint）----
function applyCapacityConstraint(
  result: ReplenishmentResult,
  sku: SkuData,
  config: SkillConfig,
) {
  if (!config.enableCapacityConstraint) return

  const status = sku.capacity_status
  const maxSupply = sku.max_supply_qty

  if (status === 'unavailable' || maxSupply == null) {
    if (sku.supplier_id) {
      result.warnings.push('供应商暂无产能回告数据,该SKU按无约束处理')
      result.calculation_notes.push('产能约束: 无回告数据,跳过')
    }
    return
  }

  result.supplier_max_supply = maxSupply

  if (maxSupply <= 0) {
    result.replenishment_qty = 0
    result.warnings.push('供应商产能回告为0(无法供货),需人工确认替代供应商')
    result.need_manual_review = true
    result.calculation_notes.push('产能约束: 供应商无法供货,补货量置0')
    return
  }

  if (result.replenishment_qty > maxSupply) {
    result.calculation_notes.push(
      `产能约束: 建议补货量${result.replenishment_qty}超供应商产能上限${maxSupply},已按产能封顶`,
    )
    result.warnings.push(
      `产能受限: 建议补货${result.suggested_qty}件,供应商仅可供${maxSupply}件,已按产能封顶`,
    )
    result.replenishment_qty = Math.floor(maxSupply)
    result.need_manual_review = true
  } else {
    result.calculation_notes.push(
      `产能约束: 补货量${result.replenishment_qty}未超供应商产能上限${maxSupply}`,
    )
  }
}

// ---- 单个SKU补货计算（对应 calculate_replenishment）----
export function calculateReplenishment(
  sku: SkuData,
  config: SkillConfig,
  currentDate: Date,
): ReplenishmentResult {
  const result: ReplenishmentResult = {
    sku_id: sku.sku_id,
    replenishment_qty: 0,
    suggested_qty: 0,
    supplier_max_supply: null,
    daily_sales: 0,
    target_turnover_days: 0,
    orderable_stock: 0,
    warnings: [],
    need_manual_review: false,
    calculation_notes: [],
  }

  try {
    // 1. 日均销量
    const { dailySales, note: salesNote } = calculateDailySales(sku, config)
    result.daily_sales = dailySales
    result.calculation_notes.push(`日均销量: ${dailySales.toFixed(2)} - ${salesNote}`)

    // 2. 零销量拦截
    if (dailySales === 0) {
      result.warnings.push('日均销量为0,需人工指定其他销量类型')
      result.need_manual_review = true
      return result
    }

    // 3. 目标周转天数
    const { targetDays, note: daysNote } = getTargetTurnoverDays(config, currentDate)
    result.target_turnover_days = targetDays
    result.calculation_notes.push(`目标周转: ${targetDays}天 - ${daysNote}`)

    // 4. 可订购库存
    const orderable = (sku.current_stock || 0) + (sku.in_transit_stock || 0)
    result.orderable_stock = orderable
    result.calculation_notes.push(
      `可订购库存: ${orderable} (当前${sku.current_stock || 0} + 在途${sku.in_transit_stock || 0})`,
    )

    // 5. 补货量公式
    const replenishment = Math.floor(targetDays * dailySales - orderable)
    const suggested = Math.max(0, replenishment)
    result.suggested_qty = suggested
    result.replenishment_qty = suggested
    result.calculation_notes.push(
      `补货量: ${targetDays} × ${dailySales.toFixed(2)} - ${orderable} = ${replenishment}`,
    )

    // 6. 供应商产能约束
    applyCapacityConstraint(result, sku, config)

    // 7. 异常场景检查
    const unitPrice = sku.unit_price || 0
    if (unitPrice > 0) {
      const orderAmount = result.replenishment_qty * unitPrice
      if (orderAmount > config.largeOrderThreshold) {
        result.warnings.push(
          `大额订单: 补货金额${orderAmount.toFixed(2)}元超过阈值${config.largeOrderThreshold}元`,
        )
        result.need_manual_review = true
      }
    }
    const age = sku.inventory_age || 0
    if (age > config.longAgeThreshold) {
      result.warnings.push(`长库龄: 库龄${age}天超过阈值${config.longAgeThreshold}天`)
      result.need_manual_review = true
    }
  } catch (e: any) {
    result.warnings.push(`计算异常: ${e.message || String(e)}`)
    result.need_manual_review = true
  }

  return result
}

export function batchCalculate(
  skus: SkuData[],
  config: SkillConfig,
  currentDate: Date,
): ReplenishmentResult[] {
  return skus.map((s) => calculateReplenishment(s, config, currentDate))
}

// ---- Excel格式校验（对应 validate_excel_format）----
export function validateExcel(skus: SkuData[]): {
  valid: boolean
  errors: string[]
  warnings: string[]
  sku_count: number
} {
  const errors: string[] = []
  const warnings: string[] = []
  if (!skus || skus.length === 0) {
    errors.push('Excel文件没有数据')
  }
  skus.forEach((s) => {
    if (!s.sku_id) errors.push('存在缺少SKU ID的行')
  })
  return { valid: errors.length === 0, errors, warnings, sku_count: skus.length }
}

// ---- Mock API: 供应商产能查询（对应 api/供应商产能查询.json）----
export function mockQuerySupplierCapacity(skus: SkuData[]): CapacityRecord[] {
  // 演示环境用SKU内置的产能字段模拟"供应商回告"
  return skus
    .filter((s) => s.supplier_id)
    .map((s) => ({
      skuId: s.sku_id,
      supplierId: s.supplier_id!,
      maxSupplyQty: s.max_supply_qty ?? -1,
      leadTimeDays: s.lead_time_days ?? 7,
      capacityStatus:
        s.max_supply_qty == null
          ? 'unavailable'
          : (s.capacity_status ?? 'normal'),
    }))
    .filter((c) => c.maxSupplyQty >= 0 || c.capacityStatus === 'unavailable')
}

// ---- 合并产能数据（对应 merge_capacity_data）----
export function mergeCapacityData(
  skus: SkuData[],
  capacityList: CapacityRecord[],
): SkuData[] {
  const index = new Map<string, CapacityRecord>()
  capacityList.forEach((c) => index.set(`${c.skuId}|${c.supplierId}`, c))
  return skus.map((s) => {
    const cap = index.get(`${s.sku_id}|${s.supplier_id}`)
    if (cap && cap.capacityStatus !== 'unavailable') {
      return {
        ...s,
        max_supply_qty: cap.maxSupplyQty,
        capacity_status: cap.capacityStatus,
        lead_time_days: cap.leadTimeDays,
      }
    }
    return { ...s, capacity_status: 'unavailable' as const }
  })
}

// ---- Mock API: 采购建单上传（对应 api/采购建单上传.json）----
export function mockUploadPurchaseOrder(rows: ReplenishmentResult[]): {
  code: number
  taskId: string
  taskName: string
  count: number
} {
  const ts = new Date()
  const pad = (n: number) => String(n).padStart(2, '0')
  const taskName = `补货建单_${ts.getFullYear()}${pad(ts.getMonth() + 1)}${pad(
    ts.getDate(),
  )}${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}`
  return {
    code: 200,
    taskId: 'TASK-' + Math.random().toString(36).slice(2, 10).toUpperCase(),
    taskName,
    count: rows.length,
  }
}

// ---- 生成建单模板（对应 generate_purchase_template）----
export function generatePurchaseRows(
  results: ReplenishmentResult[],
): ReplenishmentResult[] {
  return results.filter((r) => !r.need_manual_review && r.replenishment_qty > 0)
}
