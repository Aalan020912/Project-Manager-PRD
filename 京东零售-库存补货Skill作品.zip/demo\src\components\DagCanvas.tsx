import { useMemo } from 'react'
import { Code2, Cloud, MessageSquare, Check, X, Loader2, Minus } from 'lucide-react'
import { DAG_NODES, DAG_EDGES, computeLayers } from '../lib/dag'
import type { NodeRunState, NodeStatus, NodeType } from '../lib/types'

const CANVAS_W = 620
const LAYER_H = 118
const NODE_W = 224
const NODE_H = 62
const TOP = 46

const typeIcon: Record<NodeType, React.ReactNode> = {
  code_interpreter: <Code2 className="w-3.5 h-3.5" />,
  api_call: <Cloud className="w-3.5 h-3.5" />,
  tool_call: <MessageSquare className="w-3.5 h-3.5" />,
}

const typeLabel: Record<NodeType, string> = {
  code_interpreter: '脚本',
  api_call: 'API',
  tool_call: '工具',
}

function statusStyle(status: NodeStatus) {
  switch (status) {
    case 'running':
      return 'border-brand-500 bg-brand-50 shadow-lg shadow-brand-500/20 animate-pulse-ring'
    case 'success':
      return 'border-emerald-400 bg-emerald-50'
    case 'warning':
      return 'border-amber-400 bg-amber-50'
    case 'skipped':
      return 'border-slate-300 bg-slate-50 border-dashed opacity-60'
    default:
      return 'border-slate-200 bg-white'
  }
}

function StatusIcon({ status }: { status: NodeStatus }) {
  switch (status) {
    case 'running':
      return <Loader2 className="w-4 h-4 text-brand-600 animate-spin" />
    case 'success':
      return <Check className="w-4 h-4 text-emerald-600" />
    case 'warning':
      return <X className="w-4 h-4 text-amber-600" />
    case 'skipped':
      return <Minus className="w-4 h-4 text-slate-400" />
    default:
      return <div className="w-2 h-2 rounded-full bg-slate-300" />
  }
}

interface Props {
  states: Record<string, NodeRunState>
}

export default function DagCanvas({ states }: Props) {
  const { positions, layers } = useMemo(() => {
    const layers = computeLayers()
    const positions = new Map<string, { x: number; y: number }>()
    layers.forEach((layer, i) => {
      layer.forEach((id, j) => {
        const x = (CANVAS_W * (j + 1)) / (layer.length + 1)
        const y = TOP + i * LAYER_H + NODE_H / 2
        positions.set(id, { x, y })
      })
    })
    return { positions, layers }
  }, [])

  const canvasH = TOP + layers.length * LAYER_H
  const nodeMap = new Map(DAG_NODES.map((n) => [n.id, n]))

  return (
    <div className="relative mx-auto" style={{ width: CANVAS_W, height: canvasH }}>
      {/* 边 */}
      <svg className="absolute inset-0" width={CANVAS_W} height={canvasH}>
        <defs>
          <marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
            <path d="M0,0 L6,3 L0,6 Z" fill="#94a3b8" />
          </marker>
        </defs>
        {DAG_EDGES.map((e, i) => {
          const from = positions.get(e.from)!
          const to = positions.get(e.to)!
          const x1 = from.x
          const y1 = from.y + NODE_H / 2
          const x2 = to.x
          const y2 = to.y - NODE_H / 2
          const midY = (y1 + y2) / 2
          const active =
            states[e.from]?.status === 'success' || states[e.from]?.status === 'warning'
          const flowing = states[e.to]?.status === 'running' && active
          return (
            <path
              key={i}
              d={`M ${x1} ${y1} C ${x1} ${midY}, ${x2} ${midY}, ${x2} ${y2}`}
              fill="none"
              stroke={active ? '#3366ff' : '#cbd5e1'}
              strokeWidth={active ? 2 : 1.5}
              markerEnd="url(#arrow)"
              strokeDasharray={flowing ? '5 5' : undefined}
              className={flowing ? 'animate-flow' : ''}
              opacity={active ? 0.9 : 0.5}
            />
          )
        })}
      </svg>

      {/* 节点 */}
      {DAG_NODES.map((node) => {
        const pos = positions.get(node.id)!
        const st = states[node.id] || { status: 'idle', logs: [] }
        return (
          <div
            key={node.id}
            className={`absolute rounded-xl border-2 px-3 py-2 transition-all duration-300 ${statusStyle(
              st.status,
            )}`}
            style={{
              width: NODE_W,
              height: NODE_H,
              left: pos.x - NODE_W / 2,
              top: pos.y - NODE_H / 2,
            }}
          >
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1 text-[10px] font-medium text-slate-500 bg-slate-100 rounded px-1.5 py-0.5">
                {typeIcon[node.type]}
                {typeLabel[node.type]}
              </span>
              <div className="flex items-center gap-1.5">
                {st.durationMs != null && st.status !== 'skipped' && (
                  <span className="text-[10px] text-slate-400 font-mono">{st.durationMs}ms</span>
                )}
                <StatusIcon status={st.status} />
              </div>
            </div>
            <div className="mt-1 text-[13px] font-semibold text-slate-800 truncate">
              {node.display_name}
              {node.condition && (
                <span className="ml-1 text-[9px] font-normal text-amber-600 bg-amber-50 rounded px-1 align-middle">
                  条件
                </span>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
