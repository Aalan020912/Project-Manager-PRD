# SKU补货量计算与采购订单生成 Skill

智能计算SKU补货量,自动生成采购订单,优化库存周转效率。

## 🎯 核心功能

- ✅ **智能计算**: 基于销量数据和库存状态,自动计算最优补货量
- ✅ **场景适配**: 自动识别大促、雨天等特殊场景,调整计算策略
- ✅ **产能约束**: 接入供应商产能回告,补货量按供应商可供货上限自动封顶
- ✅ **风险预警**: 大额订单、长库龄等异常场景自动提醒人工介入
- ✅ **自动建单**: 补货结果自动填充采购建单模板,一键创建采购订单

## 📦 目录结构

```
sku-replenishment-calculation/
├── SKILL.md              # Skill入口: 元数据 + 操作指令(渐进式披露第2层)
├── manifest.json         # DAG流程编排配置
├── README.md             # 本文件
├── USAGE.md              # 使用说明
├── LICENSE.txt           # 版权与数据声明
├── requirements.txt      # Python依赖
├── config/               # 参数配置包(9个参数,代码按 parameterName 聚合读取)
│   ├── README.md
│   ├── 目标周转天数.json
│   ├── 28日销量权重.json
│   ├── 7日销量权重.json
│   ├── 备货类型.json
│   ├── 启用产能约束.json
│   ├── 明细拆单数量.json
│   ├── 大额订单阈值.json
│   ├── 长库龄阈值.json
│   └── 结果接收邮箱.json
├── api/                  # 接口配置包
│   ├── README.md
│   ├── 供应商产能查询.json
│   └── 采购建单上传.json
├── scripts/              # 脚本工具包
│   ├── README.md
│   ├── calculate_replenishment.py   # 计算内核,仅依赖标准库
│   ├── excel_processor.py           # 表格解析与建单模板生成
│   └── validate_config.py           # 配置校验
├── tests/                # 测试(53个用例)
│   ├── test_calculation.py          # 计算逻辑,零第三方依赖
│   └── test_pipeline.py             # 端到端链路
└── templates/
    └── 补货计算数据样例.csv          # 7条样例,覆盖全部异常分支
```

## 🚀 快速开始

### 方式一: 本地直接验证(无需平台)

```bash
pip install -r requirements.txt

# 跑测试: 53个用例覆盖全部计算分支
python3 tests/test_calculation.py
python3 tests/test_pipeline.py

# 用内置样例跑通完整链路,结果输出到 ./output/
python3 scripts/calculate_replenishment.py
python3 scripts/excel_processor.py
```

> 计算内核不依赖第三方库,`tests/test_calculation.py` 在纯标准库环境即可运行。

### 方式二: 作为Skill调用

```
帮我计算补货量,文件路径: /path/to/sku_data.csv
```

系统会自动生成:
- 补货计算结果Excel(含计算过程与异常提示)
- 采购建单模板Excel(仅含可自动建单的SKU)
- 需人工审核的SKU清单

## 📖 详细文档

- **使用说明**: [USAGE.md](USAGE.md)
- **Skill详解**: [SKILL.md](SKILL.md)
- **参数配置**: [config/README.md](config/README.md)
- **接口说明**: [api/README.md](api/README.md)
- **脚本工具**: [scripts/README.md](scripts/README.md)

## 💡 核心公式

```
补货量 = 目标周转天数 × 日均销量 - 可订购库存

其中:
- 日均销量 = (28日销量 ÷ 28 × 权重) + (7日销量 ÷ 7 × 权重)
- 可订购库存 = 现货库存 + 在途库存
```

## 🎨 特殊场景

| 场景 | 触发条件 | 自动调整 |
|------|---------|---------|
| 大促备货 | 5月30日/10月30日前45天 | 目标周转: 35天 → 45天 |
| 雨天场景 | 过去7天有雨 | 7日权重: 0.5 → 0, 启用14日销量 |
| 供应商产能约束 | 补货量 > 产能上限 | 补货量按供应商产能回告封顶,标记审核 |
| 大额订单 | 补货金额 > 100万 | 标记需人工审核 |
| 长库龄 | 库龄 > 90天 | 标记需人工审核 |

## ⚙️ 参数配置

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 目标周转天数 | 35 | 目标库存天数 |
| 28日销量权重 | 0.5 | 28日销量权重 |
| 7日销量权重 | 0.5 | 7日销量权重 |
| 备货类型 | 5 | 采购单备货类型 |
| 明细拆单数量 | 40 | 单采购单SKU上限 |
| 大额订单阈值 | 100万 | 需人工审核的金额阈值 |
| 长库龄阈值 | 90天 | 需人工审核的库龄阈值 |

## 🔧 验证配置

运行配置验证脚本:

```bash
python3 scripts/validate_config.py
```

## 📝 示例

### 日常补货

```
用户: 计算补货量,文件: /tmp/sku_data.xlsx

系统: 
✅ 解析 100 个SKU
✅ 计算完成
✅ 平均补货量 150件
⚠️  需人工审核: 5 个SKU
```

### 大促备货

```
用户: 计算618备货量,文件: /tmp/promotion_sku.xlsx

系统:
🎯 618大促前备货
✅ 目标周转调整为45天
✅ 平均补货量 250件 (+67%)
```

## ❓ 常见问题

**Q: 为什么有些SKU没有被计算?**  
A: 可能是日均销量为0、补货量为负、或数据格式错误。

**Q: 权重可以临时调整吗?**  
A: 可以,调用时传入自定义权重参数即可。

**Q: 采购单创建失败怎么办?**  
A: 检查Cookie是否过期、参数是否正确、网络是否正常。

## 📊 统计信息

- **版本**: 1.0.0
- **创建时间**: 2026-04-16
- **计算内核依赖**: 无(仅 Python 标准库)
- **表格读写依赖**: pandas, openpyxl(见 `requirements.txt`)
- **测试**: 53 个用例,覆盖大促/雨天/产能封顶/四类异常拦截/配置加载

## 🤝 技术支持

遇到问题?

1. 查看 [USAGE.md](USAGE.md) 使用说明
2. 查看 [SKILL.md](SKILL.md) 详细文档
3. 运行 `python3 scripts/validate_config.py` 验证配置

---

**License**: Complete terms in LICENSE.txt
