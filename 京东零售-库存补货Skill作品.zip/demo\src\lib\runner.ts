// DAG 执行引擎：按依赖顺序逐节点执行，通过回调驱动前端动画
import type {
  RunScenario,
  SkillConfig,
  ReplenishmentResult,
  NodeStatus,
} from './types'
import { DAG_NODES } from './dag'
import {
  DEFAULT_CONFIG,
  validateExcel,
  batchCalculate,
  mockQuerySupplierCapacity,
  mergeCapacityData,
  generatePurchaseRows,
  mockUploadPurchaseOrder,
} from './skill'

export interface RunOptions {
  autoCreatePurchaseOrder: boolean
}

export interface RunOutput {
  config: SkillConfig
  results: ReplenishmentResult[]
  purchaseRows: ReplenishmentResult[]
  reviewRows: ReplenishmentResult[]
  uploadTask: { taskId: string; taskName: string; count: number } | null
  stats: {
    totalSku: number
    needReview: number
    avgQty: number
    totalAmount: number
  }
}

export interface RunnerCallbacks {
  onNodeStatus: (nodeId: string, status: NodeStatus) => void
  onNodeLog: (nodeId: string, log: string) => void
  onNodeDone: (nodeId: string, durationMs: number) => void
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

// 执行顺序：拓扑序（手工列出，保证并行关系在动画上体现为"同层几乎同时亮起"）
const EXEC_ORDER: string[][] = [
  ['validate_excel', 'load_config'],
  ['parse_excel'],
  ['query_supplier_capacity'],
  ['merge_capacity'],
  ['calculate_replenishment'],
  ['check_anomalies'],
  ['export_results'],
  ['generate_template'],
  ['upload_purchase_order'],
  ['notify_user'],
]

export async function runSkill(
  scenario: RunScenario,
  options: RunOptions,
  cb: RunnerCallbacks,
  speed = 1,
): Promise<RunOutput> {
  const config: SkillConfig = { ...DEFAULT_CONFIG, ...scenario.configOverride }
  const currentDate = new Date(scenario.simulatedDate + 'T09:00:00')
  const step = (ms: number) => sleep(ms / speed)

  let skus = scenario.skus.map((s) => ({ ...s }))
  let results: ReplenishmentResult[] = []
  let capacityList: ReturnType<typeof mockQuerySupplierCapacity> = []
  let uploadTask: RunOutput['uploadTask'] = null

  const nodeById = new Map(DAG_NODES.map((n) => [n.id, n]))

  for (const layer of EXEC_ORDER) {
    // 同层并行：先全部置 running
    const active: string[] = []
    for (const nodeId of layer) {
      const node = nodeById.get(nodeId)!
      // 条件判断
      if (node.condition === 'enableCapacityConstraint' && !config.enableCapacityConstraint) {
        cb.onNodeStatus(nodeId, 'skipped')
        cb.onNodeLog(nodeId, '条件未满足(产能约束关闭)，跳过节点')
        continue
      }
      if (node.condition === 'autoCreatePurchaseOrder' && !options.autoCreatePurchaseOrder) {
        cb.onNodeStatus(nodeId, 'skipped')
        cb.onNodeLog(nodeId, '条件未满足(未开启自动建单)，跳过 — 默认仅计算不写入')
        continue
      }
      active.push(nodeId)
      cb.onNodeStatus(nodeId, 'running')
    }

    if (active.length === 0) continue
    await step(650)

    // 执行每个节点的真实逻辑
    for (const nodeId of active) {
      const start = performance.now()
      let status: NodeStatus = 'success'

      switch (nodeId) {
        case 'validate_excel': {
          const v = validateExcel(skus)
          cb.onNodeLog(nodeId, `检查必需列与数据完整性...`)
          cb.onNodeLog(nodeId, `解析到 ${v.sku_count} 个SKU，格式校验${v.valid ? '通过' : '失败'}`)
          if (!v.valid) status = 'warning'
          break
        }
        case 'load_config': {
          cb.onNodeLog(nodeId, `目标周转=${config.targetTurnoverDays}天, 28日权重=${config.salesWeight28Days}, 7日权重=${config.salesWeight7Days}`)
          cb.onNodeLog(nodeId, `产能约束=${config.enableCapacityConstraint ? '开启' : '关闭'}, 大额阈值=${config.largeOrderThreshold}元`)
          break
        }
        case 'parse_excel': {
          cb.onNodeLog(nodeId, `列名标准化 + 类型转换...`)
          cb.onNodeLog(nodeId, `成功解析 ${skus.length} 个SKU的销量/库存/供应商数据`)
          break
        }
        case 'query_supplier_capacity': {
          capacityList = mockQuerySupplierCapacity(skus)
          cb.onNodeLog(nodeId, `[Mock API] POST /scm/supplier/capacity/batchQuery`)
          cb.onNodeLog(nodeId, `供应商回告 ${capacityList.length} 条产能记录`)
          break
        }
        case 'merge_capacity': {
          skus = mergeCapacityData(skus, capacityList)
          const matched = skus.filter((s) => s.capacity_status && s.capacity_status !== 'unavailable').length
          cb.onNodeLog(nodeId, `按(SKU,供应商)匹配合并产能数据`)
          cb.onNodeLog(nodeId, `${matched} 个SKU获得有效产能回告，其余按无约束处理`)
          break
        }
        case 'calculate_replenishment': {
          results = batchCalculate(skus, config, currentDate)
          cb.onNodeLog(nodeId, `补货量 = 目标周转 × 日均销量 - 可订购库存`)
          const capped = results.filter((r) => r.warnings.some((w) => w.includes('产能受限'))).length
          cb.onNodeLog(nodeId, `完成 ${results.length} 个SKU计算${capped > 0 ? `，其中 ${capped} 个按产能封顶` : ''}`)
          break
        }
        case 'check_anomalies': {
          const review = results.filter((r) => r.need_manual_review)
          cb.onNodeLog(nodeId, `扫描大额/长库龄/零销量/产能受限异常...`)
          cb.onNodeLog(nodeId, `拦截 ${review.length} 个需人工审核的SKU`)
          if (review.length > 0) status = 'warning'
          break
        }
        case 'export_results': {
          cb.onNodeLog(nodeId, `生成 replenishment_result.xlsx（含建议量/产能上限/异常提示）`)
          break
        }
        case 'generate_template': {
          const rows = generatePurchaseRows(results)
          cb.onNodeLog(nodeId, `过滤需审核 & 补货量为0的SKU`)
          cb.onNodeLog(nodeId, `生成 purchase_template.xlsx，含 ${rows.length} 个可下单SKU`)
          break
        }
        case 'upload_purchase_order': {
          const rows = generatePurchaseRows(results)
          const resp = mockUploadPurchaseOrder(rows)
          uploadTask = { taskId: resp.taskId, taskName: resp.taskName, count: resp.count }
          cb.onNodeLog(nodeId, `[Mock API] POST /poes/upload/uploadExcel`)
          cb.onNodeLog(nodeId, `建单任务已创建: ${resp.taskId}（${resp.count}个SKU）`)
          break
        }
        case 'notify_user': {
          const review = results.filter((r) => r.need_manual_review).length
          cb.onNodeLog(nodeId, `[tool: message] 推送结果通知`)
          cb.onNodeLog(nodeId, uploadTask ? `已建单 + ${review}个待审核，通知已发送` : `计算完成 + ${review}个待审核，等待确认是否建单`)
          break
        }
      }

      const dur = Math.round(performance.now() - start) + Math.round(120 + Math.random() * 260)
      await step(420)
      cb.onNodeStatus(nodeId, status)
      cb.onNodeDone(nodeId, dur)
    }
  }

  // 汇总统计
  const purchaseRows = generatePurchaseRows(results)
  const reviewRows = results.filter((r) => r.need_manual_review)
  const totalAmount = results.reduce(
    (sum, r) => sum + r.replenishment_qty * (skus.find((s) => s.sku_id === r.sku_id)?.unit_price || 0),
    0,
  )
  const avgQty =
    results.length > 0
      ? Math.round(results.reduce((s, r) => s + r.replenishment_qty, 0) / results.length)
      : 0

  return {
    config,
    results,
    purchaseRows,
    reviewRows,
    uploadTask,
    stats: {
      totalSku: results.length,
      needReview: reviewRows.length,
      avgQty,
      totalAmount,
    },
  }
}
