import { Send, Play, Sparkles, FileSpreadsheet, ToggleLeft, ToggleRight } from 'lucide-react'
import { SCENARIOS } from '../data/samples'
import type { RunScenario } from '../lib/types'

interface Props {
  nlInput: string
  setNlInput: (v: string) => void
  scenario: RunScenario
  onSelectScenario: (s: RunScenario) => void
  onSubmitNl: () => void
  autoCreate: boolean
  setAutoCreate: (v: boolean) => void
  running: boolean
  onRun: () => void
}

export default function InputPanel({
  nlInput,
  setNlInput,
  scenario,
  onSelectScenario,
  onSubmitNl,
  autoCreate,
  setAutoCreate,
  running,
  onRun,
}: Props) {
  return (
    <div className="flex flex-col gap-4 h-full">
      <div>
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2">
          <Sparkles className="w-4 h-4 text-brand-600" />
          自然语言指令
        </div>
        <div className="relative">
          <textarea
            value={nlInput}
            onChange={(e) => setNlInput(e.target.value)}
            placeholder="例如：618快到了，帮我算大促备货量…"
            rows={3}
            className="w-full resize-none rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100"
          />
          <button
            onClick={onSubmitNl}
            disabled={running}
            className="absolute bottom-2.5 right-2.5 inline-flex items-center gap-1 rounded-lg bg-brand-600 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-brand-700 disabled:opacity-50"
          >
            <Send className="w-3 h-3" />
            识别
          </button>
        </div>
        <p className="mt-1.5 text-[11px] text-slate-400">
          识别方式为关键词匹配（大促 / 雨天 / 产能），模拟平台的自然语言路由。
        </p>
      </div>

      <div>
        <div className="text-sm font-semibold text-slate-700 mb-2">演示场景</div>
        <div className="grid grid-cols-1 gap-2">
          {SCENARIOS.map((s) => (
            <button
              key={s.id}
              onClick={() => onSelectScenario(s)}
              disabled={running}
              className={`text-left rounded-xl border px-3 py-2.5 transition-all disabled:opacity-60 ${
                scenario.id === s.id
                  ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-200'
                  : 'border-slate-200 bg-white hover:border-brand-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-brand-600 shrink-0" />
                <span className="text-sm font-medium text-slate-800">{s.label}</span>
                <span className="ml-auto text-[11px] text-slate-400">{s.skus.length} SKU</span>
              </div>
              <p className="mt-1 text-[11px] leading-snug text-slate-500">{s.description}</p>
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white px-3 py-3">
        <button
          onClick={() => setAutoCreate(!autoCreate)}
          disabled={running}
          className="flex w-full items-center justify-between text-sm"
        >
          <div className="text-left">
            <div className="font-medium text-slate-800">自动创建采购单</div>
            <div className="text-[11px] text-slate-400">写操作·默认关闭（仅计算不建单）</div>
          </div>
          {autoCreate ? (
            <ToggleRight className="w-8 h-8 text-brand-600" />
          ) : (
            <ToggleLeft className="w-8 h-8 text-slate-300" />
          )}
        </button>
      </div>

      <button
        onClick={onRun}
        disabled={running}
        className="mt-auto inline-flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-brand-500/25 hover:bg-brand-700 disabled:opacity-50"
      >
        <Play className="w-4 h-4" />
        {running ? '正在执行工作流…' : '运行补货 Skill'}
      </button>
    </div>
  )
}
