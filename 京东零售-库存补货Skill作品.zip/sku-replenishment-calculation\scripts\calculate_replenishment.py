#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
补货量计算脚本
基于销量、库存等数据,智能计算补货建议量
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Tuple, Any
import math

# 说明: pandas 仅在导出Excel时按需导入,使补货计算逻辑本身不依赖第三方库

# 计算逻辑的默认参数,与 config/ 目录下各参数配置文件的 value 保持一致
DEFAULT_CONFIG = {
    "targetTurnoverDays": 35,
    "salesWeight28Days": 0.5,
    "salesWeight7Days": 0.5,
    "largeOrderThreshold": 1000000,
    "longAgeThreshold": 90,
    "enableCapacityConstraint": True,
}


class ReplenishmentCalculator:
    """补货量计算器"""
    
    def __init__(self, config_path: str = None, **overrides):
        """
        初始化计算器
        
        Args:
            config_path: 配置来源,可为 config/ 目录、单个JSON文件,或None(用默认值)
            **overrides: 运行时参数覆盖,优先级高于配置文件
        """
        # 加载配置
        self.config = self._load_config(config_path)
        
        # 运行时覆盖(调用skill时传入的自定义参数)
        self.config.update({k: v for k, v in overrides.items() if v is not None})
        
        # 大促日期
        self.promotion_dates = [
            {"month": 5, "day": 30, "name": "618大促"},
            {"month": 10, "day": 30, "name": "双11大促"}
        ]
    
    def _load_config(self, config_path: str = None) -> Dict:
        """
        加载配置
        
        支持三种来源,优先级由调用方决定:
        - None: 使用 DEFAULT_CONFIG
        - 目录: 聚合该目录下所有参数配置文件(按 parameterName / value 取值)
        - JSON文件: 直接作为配置字典合并到默认值上
        
        Args:
            config_path: 配置目录或文件路径
        
        Returns:
            扁平的配置字典,键为 parameterName
        """
        config = dict(DEFAULT_CONFIG)
        
        if not config_path:
            return config
        
        if os.path.isdir(config_path):
            # 聚合 config/ 目录: 每个文件描述一个参数
            for file_name in sorted(os.listdir(config_path)):
                if not file_name.endswith('.json'):
                    continue
                file_path = os.path.join(config_path, file_name)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        item = json.load(f)
                except (json.JSONDecodeError, OSError):
                    continue
                key = item.get('parameterName')
                if key and 'value' in item:
                    config[key] = item['value']
            return config
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config.update(json.load(f))
        return config
    
    def calculate_daily_sales(self, sales_28d: float, sales_7d: float, 
                              has_rain: bool = False, sales_14d: float = None) -> Tuple[float, str]:
        """
        计算日均销量
        
        Args:
            sales_28d: 28日销量
            sales_7d: 7日销量
            has_rain: 过去7天是否有雨
            sales_14d: 14日销量(雨天场景需要)
        
        Returns:
            (日均销量, 计算说明)
        """
        if has_rain:
            # 雨天场景: 7日权重为0,使用14日销量
            if sales_14d is None:
                raise ValueError("雨天场景需要提供14日销量数据")
            daily_sales = sales_14d / 14
            return daily_sales, "雨天场景:使用14日销量"
        else:
            # 正常场景: 加权平均
            weight_28d = self.config['salesWeight28Days']
            weight_7d = self.config['salesWeight7Days']
            
            # 验证权重
            if abs(weight_28d + weight_7d - 1.0) > 0.01:
                raise ValueError(f"权重之和必须为1,当前: {weight_28d + weight_7d}")
            
            # 计算28日日均和7日日均
            daily_28d = sales_28d / 28 if sales_28d > 0 else 0
            daily_7d = sales_7d / 7 if sales_7d > 0 else 0
            
            # 加权平均
            daily_sales = daily_28d * weight_28d + daily_7d * weight_7d
            
            return daily_sales, f"正常场景:28日权重={weight_28d},7日权重={weight_7d}"
    
    def get_target_turnover_days(self, current_date: datetime = None) -> Tuple[int, str]:
        """
        获取目标周转天数
        
        Args:
            current_date: 当前日期
        
        Returns:
            (目标周转天数, 调整说明)
        """
        if current_date is None:
            current_date = datetime.now()
        
        # 检查是否在大促前45天
        for promo in self.promotion_dates:
            promo_date = datetime(current_date.year, promo['month'], promo['day'])
            days_to_promo = (promo_date - current_date).days
            
            if 0 <= days_to_promo <= 45:
                return 45, f"{promo['name']}前{days_to_promo}天,调整为45天"
        
        return self.config['targetTurnoverDays'], "正常周期,默认35天"
    
    def calculate_replenishment(self, sku_data: Dict[str, Any],
                               current_date: datetime = None) -> Dict[str, Any]:
        """
        计算单个SKU的补货量
        
        Args:
            current_date: 计算基准日期,默认当天。显式传入可复现大促场景
            sku_data: SKU数据字典,包含:
                - sku_id: SKU ID
                - sales_28d: 28日销量
                - sales_7d: 7日销量
                - sales_14d: 14日销量(可选)
                - current_stock: 当前库存
                - in_transit_stock: 在途库存
                - unit_price: 单价(可选)
                - inventory_age: 库龄(可选)
                - has_rain: 过去7天是否有雨
        
        Returns:
            补货计算结果字典
        """
        result = {
            'sku_id': sku_data.get('sku_id'),
            'replenishment_qty': 0,
            'daily_sales': 0,
            'target_turnover_days': 0,
            'orderable_stock': 0,
            'suggested_qty': 0,
            'supplier_max_supply': None,
            'warnings': [],
            'need_manual_review': False,
            'calculation_notes': []
        }
        
        try:
            # 1. 计算日均销量
            daily_sales, sales_note = self.calculate_daily_sales(
                sales_28d=sku_data.get('sales_28d', 0),
                sales_7d=sku_data.get('sales_7d', 0),
                has_rain=sku_data.get('has_rain', False),
                sales_14d=sku_data.get('sales_14d')
            )
            result['daily_sales'] = daily_sales
            result['calculation_notes'].append(f"日均销量: {daily_sales:.2f} - {sales_note}")
            
            # 2. 检查日均销量为0的情况
            if daily_sales == 0:
                result['warnings'].append("日均销量为0,需人工指定其他销量类型")
                result['need_manual_review'] = True
                return result
            
            # 3. 获取目标周转天数
            target_days, days_note = self.get_target_turnover_days(current_date)
            result['target_turnover_days'] = target_days
            result['calculation_notes'].append(f"目标周转: {target_days}天 - {days_note}")
            
            # 4. 计算可订购库存
            current_stock = sku_data.get('current_stock', 0)
            in_transit_stock = sku_data.get('in_transit_stock', 0)
            orderable_stock = current_stock + in_transit_stock
            result['orderable_stock'] = orderable_stock
            result['calculation_notes'].append(f"可订购库存: {orderable_stock} (当前{current_stock} + 在途{in_transit_stock})")
            
            # 5. 计算补货量
            # 公式: 补货量 = 目标库存天数 × 日均销量 - 可订购库存
            replenishment = target_days * daily_sales - orderable_stock
            replenishment = math.floor(replenishment)  # 向下取整
            
            suggested_qty = max(0, replenishment)  # 不允许负数
            result['suggested_qty'] = suggested_qty
            result['replenishment_qty'] = suggested_qty
            result['calculation_notes'].append(f"补货量: {target_days} × {daily_sales:.2f} - {orderable_stock} = {replenishment}")
            
            # 6. 供应商产能约束(产能回告)
            self.apply_capacity_constraint(result, sku_data)
            
            # 7. 异常场景检查
            unit_price = sku_data.get('unit_price', 0)
            if unit_price > 0:
                order_amount = result['replenishment_qty'] * unit_price
                if order_amount > self.config['largeOrderThreshold']:
                    result['warnings'].append(f"大额订单: 补货金额{order_amount:.2f}元超过阈值{self.config['largeOrderThreshold']}元")
                    result['need_manual_review'] = True
            
            inventory_age = sku_data.get('inventory_age', 0)
            if inventory_age > self.config['longAgeThreshold']:
                result['warnings'].append(f"长库龄: 库龄{inventory_age}天超过阈值{self.config['longAgeThreshold']}天")
                result['need_manual_review'] = True
            
        except Exception as e:
            result['warnings'].append(f"计算异常: {str(e)}")
            result['need_manual_review'] = True
        
        return result
    
    def apply_capacity_constraint(self, result: Dict[str, Any], sku_data: Dict[str, Any]) -> None:
        """
        应用供应商产能约束(产能回告)
        
        当补货量超过供应商可供货上限时,按产能上限封顶并标记人工审核。
        产能数据(max_supply_qty/capacity_status)由产能查询节点写入sku_data。
        
        Args:
            result: 当前SKU的补货计算结果(原地修改)
            sku_data: SKU数据,可能包含供应商产能回告字段
        """
        # 开关关闭则跳过
        if not self.config.get('enableCapacityConstraint', True):
            return
        
        capacity_status = sku_data.get('capacity_status')
        max_supply = sku_data.get('max_supply_qty')
        
        # 无产能回告数据: 不阻断,记录提示
        if capacity_status == 'unavailable' or max_supply is None:
            if sku_data.get('supplier_id'):
                result['warnings'].append("供应商暂无产能回告数据,该SKU按无约束处理")
                result['calculation_notes'].append("产能约束: 无回告数据,跳过")
            return
        
        result['supplier_max_supply'] = max_supply
        
        # 供应商无法供货
        if max_supply <= 0:
            result['replenishment_qty'] = 0
            result['warnings'].append("供应商产能回告为0(无法供货),需人工确认替代供应商")
            result['need_manual_review'] = True
            result['calculation_notes'].append("产能约束: 供应商无法供货,补货量置0")
            return
        
        # 补货量超过供应商产能上限: 封顶并标记审核
        if result['replenishment_qty'] > max_supply:
            result['calculation_notes'].append(
                f"产能约束: 建议补货量{result['replenishment_qty']}超供应商产能上限{max_supply},已按产能封顶"
            )
            result['warnings'].append(
                f"产能受限: 建议补货{result['suggested_qty']}件,供应商仅可供{max_supply}件,已按产能封顶"
            )
            result['replenishment_qty'] = int(max_supply)
            result['need_manual_review'] = True
        else:
            result['calculation_notes'].append(
                f"产能约束: 补货量{result['replenishment_qty']}未超供应商产能上限{max_supply}"
            )
    
    def batch_calculate(self, sku_list: List[Dict[str, Any]],
                        current_date: datetime = None) -> List[Dict[str, Any]]:
        """
        批量计算多个SKU的补货量
        
        Args:
            sku_list: SKU数据列表
            current_date: 计算基准日期,默认当天
        
        Returns:
            补货计算结果列表
        """
        results = []
        for sku_data in sku_list:
            result = self.calculate_replenishment(sku_data, current_date)
            results.append(result)
        return results
    
    def merge_capacity_data(self, sku_list: List[Dict[str, Any]], 
                            capacity_list: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        将供应商产能回告结果合并到SKU数据中
        
        供应商产能查询API返回的capacity_list,按(skuId, supplierId)匹配写回sku_list,
        供后续calculate_replenishment的产能约束使用。
        
        Args:
            sku_list: 解析后的SKU数据列表
            capacity_list: 产能查询API返回的产能回告列表
        
        Returns:
            合并产能数据后的SKU数据列表
        """
        # 构建 (skuId, supplierId) -> 产能信息 的索引
        capacity_index = {}
        for cap in capacity_list or []:
            key = (str(cap.get('skuId')), str(cap.get('supplierId')))
            capacity_index[key] = cap
        
        for sku in sku_list:
            key = (str(sku.get('sku_id')), str(sku.get('supplier_id')))
            cap = capacity_index.get(key)
            if cap:
                sku['max_supply_qty'] = cap.get('maxSupplyQty')
                sku['capacity_status'] = cap.get('capacityStatus', 'normal')
                sku['lead_time_days'] = cap.get('leadTimeDays')
            else:
                sku['capacity_status'] = 'unavailable'
        
        return sku_list
    
    def check_anomalies(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        汇总补货结果中的异常场景
        
        单SKU层面的异常已由 calculate_replenishment 写入 warnings 并置
        need_manual_review;本方法按异常类型归类汇总,用于输出审核清单和结果通知。
        
        Args:
            results: 补货计算结果列表
        
        Returns:
            异常汇总字典,含各类型SKU编号、待审核清单与可自动建单数量
        """
        # 异常关键词 -> 分类名,与 warnings 中的文案对应
        keyword_to_category = [
            ('大额订单', 'large_order'),
            ('长库龄', 'long_inventory_age'),
            ('日均销量为0', 'zero_sales'),
            ('产能受限', 'capacity_limited'),
            ('无法供货', 'supplier_unavailable'),
            ('暂无产能回告', 'capacity_unknown'),
            ('计算异常', 'calculation_error'),
        ]
        categories = {category: [] for _, category in keyword_to_category}
        
        review_sku_ids = []
        auto_order_count = 0
        
        for result in results:
            sku_id = result.get('sku_id')
            
            if result.get('need_manual_review'):
                review_sku_ids.append(sku_id)
            elif result.get('replenishment_qty', 0) > 0:
                auto_order_count += 1
            
            for warning in result.get('warnings', []):
                for keyword, category in keyword_to_category:
                    if keyword in warning:
                        categories[category].append(sku_id)
                        break
        
        return {
            'total_sku': len(results),
            'need_review_count': len(review_sku_ids),
            'auto_order_count': auto_order_count,
            'review_sku_ids': review_sku_ids,
            'categories': categories,
        }
    
    # 结果表列名映射: 内部字段 -> 业务方可读的中文表头
    RESULT_COLUMN_MAPPING = {
        'sku_id': 'SKU ID',
        'replenishment_qty': '补货数量',
        'suggested_qty': '建议补货量',
        'supplier_max_supply': '供应商产能上限',
        'daily_sales': '日均销量',
        'target_turnover_days': '目标周转天数',
        'orderable_stock': '可订购库存',
        'warnings': '异常提示',
        'need_manual_review': '需人工审核',
        'calculation_notes': '计算说明'
    }
    
    def build_result_table(self, results: List[Dict[str, Any]]):
        """
        构建补货结果表格
        
        与文件IO分离,便于单独测试表格内容与复用于其他输出格式。
        
        Args:
            results: 补货计算结果列表
        
        Returns:
            pandas.DataFrame,列名已转为中文表头
        """
        import pandas as pd
        
        df = pd.DataFrame(results)
        
        # 列表字段展平为可读文本,避免Excel中出现Python列表字面量
        for list_column in ('warnings', 'calculation_notes'):
            if list_column in df.columns:
                df[list_column] = df[list_column].apply(
                    lambda value: ' | '.join(str(item) for item in value)
                    if isinstance(value, list) else value
                )
        
        # 布尔字段转为中文,便于业务方阅读
        if 'need_manual_review' in df.columns:
            df['need_manual_review'] = df['need_manual_review'].apply(
                lambda flag: '是' if flag else '否'
            )
        
        return df.rename(columns=self.RESULT_COLUMN_MAPPING)
    
    def export_to_excel(self, results: List[Dict[str, Any]], output_path: str):
        """
        导出补货计算结果到Excel
        
        Args:
            results: 补货计算结果列表
            output_path: 输出文件路径
        """
        df = self.build_result_table(results)
        df.to_excel(output_path, index=False, engine='openpyxl')
        print(f"补货计算结果已导出到: {output_path}")


def main():
    """主函数 - 示例用法,覆盖正常/长库龄/雨天/产能封顶/零销量五类场景"""
    # 从 config/ 目录加载参数(演示配置包如何真正生效)
    config_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config')
    calculator = ReplenishmentCalculator(config_dir if os.path.isdir(config_dir) else None)
    
    # 示例数据
    sku_list = [
        {
            'sku_id': 'SKU001',
            'sales_28d': 280,
            'sales_7d': 70,
            'current_stock': 50,
            'in_transit_stock': 20,
            'unit_price': 100,
            'inventory_age': 30,
            'has_rain': False
        },
        {
            'sku_id': 'SKU002',
            'sales_28d': 560,
            'sales_7d': 140,
            'current_stock': 100,
            'in_transit_stock': 50,
            'unit_price': 200,
            'inventory_age': 100,
            'has_rain': False
        },
        {
            'sku_id': 'SKU003',
            'sales_28d': 420,
            'sales_7d': 105,
            'current_stock': 80,
            'in_transit_stock': 40,
            'unit_price': 150,
            'inventory_age': 60,
            'has_rain': True,
            'sales_14d': 210
        },
        {
            'sku_id': 'SKU004',
            'sales_28d': 1400,
            'sales_7d': 350,
            'current_stock': 100,
            'in_transit_stock': 0,
            'unit_price': 80,
            'inventory_age': 20,
            'has_rain': False,
            'supplier_id': 'S10001',
            'max_supply_qty': 500,
            'capacity_status': 'limited'
        },
        {
            'sku_id': 'SKU005',
            'sales_28d': 0,
            'sales_7d': 0,
            'current_stock': 10,
            'in_transit_stock': 5,
            'unit_price': 300,
            'inventory_age': 120,
            'has_rain': False
        }
    ]
    
    # 批量计算
    results = calculator.batch_calculate(sku_list)
    
    # 打印结果
    for result in results:
        print(f"\nSKU: {result['sku_id']}")
        print(f"补货数量: {result['replenishment_qty']}")
        print(f"日均销量: {result['daily_sales']:.2f}")
        print(f"目标周转: {result['target_turnover_days']}天")
        print(f"异常提示: {', '.join(result['warnings']) if result['warnings'] else '无'}")
        print(f"需人工审核: {'是' if result['need_manual_review'] else '否'}")
    
    # 异常汇总
    summary = calculator.check_anomalies(results)
    print(f"\n{'=' * 50}")
    print(f"共 {summary['total_sku']} 个SKU, "
          f"可自动建单 {summary['auto_order_count']} 个, "
          f"需人工审核 {summary['need_review_count']} 个")
    for category, sku_ids in summary['categories'].items():
        if sku_ids:
            print(f"  {category}: {', '.join(map(str, sku_ids))}")
    print('=' * 50)
    
    # 导出Excel到 output/ 目录(相对路径,跨平台可用)
    try:
        output_dir = os.path.join(os.getcwd(), 'output')
        os.makedirs(output_dir, exist_ok=True)
        calculator.export_to_excel(
            results, os.path.join(output_dir, 'replenishment_result.xlsx')
        )
    except ImportError:
        print("\n跳过Excel导出: 缺少 pandas/openpyxl,可执行 pip install -r requirements.txt 后重试")


if __name__ == '__main__':
    main()
