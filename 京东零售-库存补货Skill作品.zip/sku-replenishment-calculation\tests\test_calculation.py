#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
补货计算逻辑测试

覆盖正常计算、大促调整、雨天降权、产能约束、四类异常拦截与配置加载。
所有用例均传入固定基准日期,保证结果不随运行时间变化。

运行: python3 -m unittest discover -s tests -v
"""

import os
import sys
import unittest
from datetime import datetime

sys.path.insert(
    0,
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts')
)

from calculate_replenishment import ReplenishmentCalculator  # noqa: E402

# 非大促基准日: 距618(5/30)135天、距双11(10/30)288天,均超出45天备货窗口
NORMAL_DATE = datetime(2026, 1, 15)
# 618前29天,落在45天备货窗口内
PROMOTION_DATE = datetime(2026, 5, 1)


def base_sku(**overrides):
    """构造一个无异常的基准SKU: 日均销量10件,可订购库存70件"""
    sku = {
        'sku_id': 'SKU001',
        'sales_28d': 280,
        'sales_7d': 70,
        'current_stock': 50,
        'in_transit_stock': 20,
        'unit_price': 100,
        'inventory_age': 30,
        'has_rain': False,
    }
    sku.update(overrides)
    return sku


class TestDailySales(unittest.TestCase):
    """日均销量计算"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()

    def test_weighted_average(self):
        daily, note = self.calculator.calculate_daily_sales(sales_28d=280, sales_7d=70)
        self.assertAlmostEqual(daily, 10.0)
        self.assertIn('正常场景', note)

    def test_rain_uses_14d(self):
        daily, note = self.calculator.calculate_daily_sales(
            sales_28d=420, sales_7d=105, has_rain=True, sales_14d=210
        )
        self.assertAlmostEqual(daily, 15.0)
        self.assertIn('雨天', note)

    def test_rain_without_14d_raises(self):
        with self.assertRaises(ValueError):
            self.calculator.calculate_daily_sales(
                sales_28d=420, sales_7d=105, has_rain=True, sales_14d=None
            )

    def test_invalid_weights_raise(self):
        calculator = ReplenishmentCalculator(salesWeight28Days=0.7, salesWeight7Days=0.5)
        with self.assertRaises(ValueError):
            calculator.calculate_daily_sales(sales_28d=280, sales_7d=70)


class TestTargetTurnoverDays(unittest.TestCase):
    """目标周转天数与大促调整"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()

    def test_normal_period(self):
        days, note = self.calculator.get_target_turnover_days(NORMAL_DATE)
        self.assertEqual(days, 35)
        self.assertIn('正常周期', note)

    def test_promotion_period(self):
        days, note = self.calculator.get_target_turnover_days(PROMOTION_DATE)
        self.assertEqual(days, 45)
        self.assertIn('618大促', note)


class TestReplenishmentCalculation(unittest.TestCase):
    """单SKU补货量计算"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()

    def test_normal_case(self):
        # 35天 × 日均10件 - 可订购70件 = 280件
        result = self.calculator.calculate_replenishment(base_sku(), NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 280)
        self.assertEqual(result['target_turnover_days'], 35)
        self.assertEqual(result['orderable_stock'], 70)
        self.assertFalse(result['need_manual_review'])
        self.assertEqual(result['warnings'], [])

    def test_promotion_increases_quantity(self):
        # 大促窗口内目标周转升至45天: 45 × 10 - 70 = 380件
        result = self.calculator.calculate_replenishment(base_sku(), PROMOTION_DATE)
        self.assertEqual(result['replenishment_qty'], 380)
        self.assertEqual(result['target_turnover_days'], 45)

    def test_rain_scenario(self):
        # 雨天改用14日销量: 35 × 15 - 120 = 405件
        sku = base_sku(
            sku_id='SKU003', sales_28d=420, sales_7d=105, sales_14d=210,
            current_stock=80, in_transit_stock=40, unit_price=150, has_rain=True
        )
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 405)
        self.assertFalse(result['need_manual_review'])

    def test_rain_missing_14d_goes_to_review(self):
        sku = base_sku(has_rain=True, sales_14d=None)
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('计算异常' in w for w in result['warnings']))

    def test_sufficient_stock_yields_zero(self):
        # 库存已超目标,补货量不允许为负
        result = self.calculator.calculate_replenishment(
            base_sku(current_stock=5000), NORMAL_DATE
        )
        self.assertEqual(result['replenishment_qty'], 0)

    def test_missing_optional_fields(self):
        # 仅提供必需字段,可选字段缺失不应报错
        sku = {'sku_id': 'SKU_MIN', 'sales_28d': 280, 'sales_7d': 70, 'current_stock': 50}
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 300)
        self.assertFalse(result['need_manual_review'])


class TestAnomalyInterception(unittest.TestCase):
    """异常场景拦截"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()

    def test_zero_sales(self):
        result = self.calculator.calculate_replenishment(
            base_sku(sales_28d=0, sales_7d=0), NORMAL_DATE
        )
        self.assertTrue(result['need_manual_review'])
        self.assertEqual(result['replenishment_qty'], 0)
        self.assertTrue(any('日均销量为0' in w for w in result['warnings']))

    def test_long_inventory_age(self):
        result = self.calculator.calculate_replenishment(
            base_sku(inventory_age=100), NORMAL_DATE
        )
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('长库龄' in w for w in result['warnings']))

    def test_large_order_amount(self):
        # 3500件 × 400元 = 140万,超过100万阈值
        sku = base_sku(
            sales_28d=2800, sales_7d=700, current_stock=0,
            in_transit_stock=0, unit_price=400
        )
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 3500)
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('大额订单' in w for w in result['warnings']))


class TestCapacityConstraint(unittest.TestCase):
    """供应商产能约束"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()
        # 建议补货量: 35 × 50 - 100 = 1650件
        self.high_demand_sku = base_sku(
            sku_id='SKU004', sales_28d=1400, sales_7d=350,
            current_stock=100, in_transit_stock=0, unit_price=80,
            inventory_age=20, supplier_id='S10001'
        )

    def test_capped_by_supplier_capacity(self):
        sku = dict(self.high_demand_sku, max_supply_qty=500, capacity_status='limited')
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['suggested_qty'], 1650)
        self.assertEqual(result['replenishment_qty'], 500)
        self.assertEqual(result['supplier_max_supply'], 500)
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('产能受限' in w for w in result['warnings']))

    def test_supplier_unavailable(self):
        sku = dict(self.high_demand_sku, max_supply_qty=0, capacity_status='limited')
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 0)
        self.assertTrue(result['need_manual_review'])
        self.assertTrue(any('无法供货' in w for w in result['warnings']))

    def test_within_capacity(self):
        sku = dict(self.high_demand_sku, max_supply_qty=5000, capacity_status='normal')
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 1650)
        self.assertFalse(result['need_manual_review'])

    def test_no_capacity_feedback(self):
        sku = dict(self.high_demand_sku, capacity_status='unavailable')
        result = self.calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 1650)
        self.assertTrue(any('暂无产能回告' in w for w in result['warnings']))

    def test_constraint_disabled(self):
        calculator = ReplenishmentCalculator(enableCapacityConstraint=False)
        sku = dict(self.high_demand_sku, max_supply_qty=500, capacity_status='limited')
        result = calculator.calculate_replenishment(sku, NORMAL_DATE)
        self.assertEqual(result['replenishment_qty'], 1650)
        self.assertIsNone(result['supplier_max_supply'])


class TestCapacityMerge(unittest.TestCase):
    """产能回告数据合并"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()

    def test_merge_by_sku_and_supplier(self):
        sku_list = [
            {'sku_id': 'SKU001', 'supplier_id': 'S10001'},
            {'sku_id': 'SKU002', 'supplier_id': 'S10002'},
        ]
        capacity_list = [{
            'skuId': 'SKU001', 'supplierId': 'S10001',
            'maxSupplyQty': 800, 'leadTimeDays': 5, 'capacityStatus': 'limited'
        }]
        merged = self.calculator.merge_capacity_data(sku_list, capacity_list)

        self.assertEqual(merged[0]['max_supply_qty'], 800)
        self.assertEqual(merged[0]['capacity_status'], 'limited')
        self.assertEqual(merged[0]['lead_time_days'], 5)
        # 未回告的SKU标记为unavailable,按无约束处理
        self.assertEqual(merged[1]['capacity_status'], 'unavailable')

    def test_empty_capacity_list(self):
        sku_list = [{'sku_id': 'SKU001', 'supplier_id': 'S10001'}]
        merged = self.calculator.merge_capacity_data(sku_list, [])
        self.assertEqual(merged[0]['capacity_status'], 'unavailable')


class TestAnomalySummary(unittest.TestCase):
    """异常汇总"""

    def setUp(self):
        self.calculator = ReplenishmentCalculator()

    def test_summary_counts_and_categories(self):
        sku_list = [
            base_sku(sku_id='OK'),
            base_sku(sku_id='AGED', inventory_age=100),
            base_sku(sku_id='ZERO', sales_28d=0, sales_7d=0),
        ]
        results = self.calculator.batch_calculate(sku_list, NORMAL_DATE)
        summary = self.calculator.check_anomalies(results)

        self.assertEqual(summary['total_sku'], 3)
        self.assertEqual(summary['need_review_count'], 2)
        self.assertEqual(summary['auto_order_count'], 1)
        self.assertIn('AGED', summary['categories']['long_inventory_age'])
        self.assertIn('ZERO', summary['categories']['zero_sales'])
        self.assertCountEqual(summary['review_sku_ids'], ['AGED', 'ZERO'])


class TestConfigLoading(unittest.TestCase):
    """配置加载"""

    def test_defaults(self):
        calculator = ReplenishmentCalculator()
        self.assertEqual(calculator.config['targetTurnoverDays'], 35)
        self.assertEqual(calculator.config['salesWeight28Days'], 0.5)

    def test_runtime_override(self):
        calculator = ReplenishmentCalculator(targetTurnoverDays=40)
        self.assertEqual(calculator.config['targetTurnoverDays'], 40)

    def test_load_from_config_directory(self):
        config_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'config'
        )
        calculator = ReplenishmentCalculator(config_dir)
        # 参数值来自 config/*.json 的 parameterName / value
        self.assertEqual(calculator.config['targetTurnoverDays'], 35)
        self.assertEqual(calculator.config['longAgeThreshold'], 90)
        self.assertTrue(calculator.config['enableCapacityConstraint'])

    def test_directory_override_takes_precedence(self):
        config_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'config'
        )
        calculator = ReplenishmentCalculator(config_dir, targetTurnoverDays=50)
        self.assertEqual(calculator.config['targetTurnoverDays'], 50)


if __name__ == '__main__':
    unittest.main(verbosity=2)
