#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Excel文件处理脚本
处理用户上传的Excel文件,提取SKU数据并生成采购建单模板
"""

import pandas as pd
from typing import Dict, List, Any, Optional
import math
import os
import sys

# 支持的输入文件格式
SUPPORTED_EXTENSIONS = ('.xlsx', '.xls', '.csv')


class ExcelProcessor:
    """Excel文件处理器"""
    
    def __init__(self):
        """初始化处理器"""
        # Excel列名映射
        self.column_mapping = {
            'sku_id': ['SKU ID', 'SKU编号', 'sku_id', 'skuId'],
            'sales_28d': ['28日销量', '28日有效销量', 'sales_28d'],
            'sales_7d': ['7日销量', '7日有效销量', 'sales_7d'],
            'sales_14d': ['14日销量', '14日有效销量', 'sales_14d'],
            'current_stock': ['当前库存', '现货库存', 'current_stock'],
            'in_transit_stock': ['在途库存', 'in_transit_stock'],
            'unit_price': ['单价', 'unit_price'],
            'inventory_age': ['库龄', '库存天数', 'inventory_age'],
            'has_rain': ['是否有雨', '雨天标记', 'has_rain'],
            'supplier_id': ['供应商编号', '供应商ID', 'supplier_id', 'supplierId']
        }
    
    def _read_table(self, file_path: str) -> pd.DataFrame:
        """
        读取表格文件,按扩展名分派
        
        Args:
            file_path: 输入文件路径,支持 .xlsx/.xls/.csv
        
        Returns:
            原始DataFrame
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")
        
        extension = os.path.splitext(file_path)[1].lower()
        if extension not in SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"不支持的文件格式: {extension},仅支持 {', '.join(SUPPORTED_EXTENSIONS)}"
            )
        
        if extension == '.csv':
            # utf-8-sig 兼容Excel导出的带BOM的CSV
            return pd.read_csv(file_path, encoding='utf-8-sig')
        return pd.read_excel(file_path)
    
    def parse_upload_excel(self, file_path: str) -> List[Dict[str, Any]]:
        """
        解析用户上传的数据文件
        
        Args:
            file_path: 输入文件路径,支持 .xlsx/.xls/.csv
        
        Returns:
            SKU数据列表
        """
        df = self._read_table(file_path)
        
        # 标准化列名
        df = self._standardize_columns(df)
        
        # 转换为字典列表
        sku_list = []
        for _, row in df.iterrows():
            sku_data = {
                'sku_id': str(row.get('sku_id', '')).strip(),
                'sales_28d': self._safe_float(row.get('sales_28d')),
                'sales_7d': self._safe_float(row.get('sales_7d')),
                # 14日销量保持None语义: 雨天场景下缺失需要显式报错,不能当成0
                'sales_14d': self._safe_float_or_none(row.get('sales_14d')),
                'current_stock': self._safe_float(row.get('current_stock')),
                'in_transit_stock': self._safe_float(row.get('in_transit_stock')),
                'unit_price': self._safe_float(row.get('unit_price')),
                'inventory_age': self._safe_float(row.get('inventory_age')),
                'has_rain': self._parse_boolean(row.get('has_rain', False)),
                'supplier_id': str(row.get('supplier_id', '')).strip()
            }
            sku_list.append(sku_data)
        
        return sku_list
    
    def _standardize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """标准化列名"""
        column_map = {}
        for standard_name, possible_names in self.column_mapping.items():
            for col in df.columns:
                if col in possible_names or str(col).strip() in possible_names:
                    column_map[col] = standard_name
                    break
        
        return df.rename(columns=column_map)
    
    def _safe_float_or_none(self, value: Any) -> Optional[float]:
        """
        转换为浮点数,缺失时返回None
        
        空单元格经pandas读取后是NaN,必须与真实的0区分:
        NaN会污染后续算术并导致 math.floor 抛异常。
        """
        if value is None:
            return None
        if isinstance(value, float) and math.isnan(value):
            return None
        if isinstance(value, str) and not value.strip():
            return None
        try:
            result = float(value)
        except (ValueError, TypeError):
            return None
        return None if math.isnan(result) else result
    
    def _safe_float(self, value: Any, default: float = 0.0) -> float:
        """安全转换为浮点数,缺失/NaN/无法解析时返回默认值"""
        result = self._safe_float_or_none(value)
        return default if result is None else result
    
    def _parse_boolean(self, value: Any) -> bool:
        """解析布尔值"""
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ['true', 'yes', '是', '1', 't', 'y']
        if isinstance(value, (int, float)):
            return bool(value)
        return False
    
    # 采购建单模板列顺序,需与建单接口的解析顺序一致
    PURCHASE_TEMPLATE_COLUMNS = [
        'SKU ID', '补货数量', '日均销量', '目标周转天数', '可订购库存'
    ]
    
    def build_purchase_table(self, replenishment_results: List[Dict[str, Any]],
                            template_type: str = 'normal') -> pd.DataFrame:
        """
        构建采购建单表格
        
        与文件IO分离,便于单独测试筛选规则。仅保留补货量>0且无需人工审核的SKU。
        
        Args:
            replenishment_results: 补货计算结果列表
            template_type: 模板类型,当前仅实现 normal;内采/ECLP 为预留类型
        
        Returns:
            pandas.DataFrame,列顺序与建单接口一致
        """
        if template_type != 'normal':
            raise NotImplementedError(
                f"模板类型 '{template_type}' 尚未实现,当前仅支持 normal"
            )
        
        purchase_data = []
        for result in replenishment_results:
            # 跳过需要人工审核的SKU
            if result.get('need_manual_review', False):
                continue
            
            # 跳过补货量为0的SKU
            if result.get('replenishment_qty', 0) <= 0:
                continue
            
            purchase_row = {
                'SKU ID': result['sku_id'],
                '补货数量': result['replenishment_qty'],
                '日均销量': round(result['daily_sales'], 2),
                '目标周转天数': result['target_turnover_days'],
                '可订购库存': result['orderable_stock']
            }
            purchase_data.append(purchase_row)
        
        # 显式指定列,保证无可建单SKU时仍输出合法表头
        return pd.DataFrame(purchase_data, columns=self.PURCHASE_TEMPLATE_COLUMNS)
    
    def generate_purchase_template(self, replenishment_results: List[Dict[str, Any]], 
                                  output_path: str, template_type: str = 'normal'):
        """
        生成采购建单Excel模板
        
        Args:
            replenishment_results: 补货计算结果列表
            output_path: 输出文件路径
            template_type: 模板类型,当前仅实现 normal;内采/ECLP 为预留类型
        
        Returns:
            输出文件路径
        """
        df = self.build_purchase_table(replenishment_results, template_type)
        
        # 导出Excel
        df.to_excel(output_path, index=False, engine='openpyxl')
        print(f"采购建单模板已生成: {output_path}")
        print(f"共 {len(df)} 个SKU需要补货")
        
        return output_path
    
    def validate_excel_format(self, file_path: str) -> Dict[str, Any]:
        """
        验证输入文件格式
        
        Args:
            file_path: 输入文件路径,支持 .xlsx/.xls/.csv
        
        Returns:
            验证结果,含 valid / errors / warnings / sku_count
        """
        result = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'sku_count': 0
        }
        
        # 必需字段 -> 提示用的展示名
        required_fields = {
            'sku_id': 'SKU ID',
            'sales_28d': '28日销量',
            'sales_7d': '7日销量',
            'current_stock': '当前库存',
        }
        
        try:
            df = self._read_table(file_path)
            present_columns = [str(col).strip() for col in df.columns]
            
            # 逐个必需字段检查是否有任一别名命中
            missing_columns = [
                display_name
                for field, display_name in required_fields.items()
                if not any(col in self.column_mapping[field] for col in present_columns)
            ]
            
            if missing_columns:
                result['valid'] = False
                result['errors'].append(f"缺少必需列: {', '.join(missing_columns)}")
            
            # 检查数据行数
            if len(df) == 0:
                result['valid'] = False
                result['errors'].append("文件没有数据行")
            
            result['sku_count'] = len(df)
            
            # 供应商列缺失时产能约束无法生效,提示但不阻断
            has_supplier = any(
                col in self.column_mapping['supplier_id'] for col in present_columns
            )
            if not has_supplier:
                result['warnings'].append("未找到供应商编号列,产能约束将不生效")
            
            # 雨天SKU缺少14日销量会在计算阶段被拦截,提前预警
            standardized = self._standardize_columns(df)
            if 'has_rain' in standardized.columns:
                rain_rows = standardized[
                    standardized['has_rain'].apply(self._parse_boolean)
                ]
                if len(rain_rows) > 0:
                    if 'sales_14d' not in standardized.columns:
                        missing_14d = len(rain_rows)
                    else:
                        missing_14d = sum(
                            1 for value in rain_rows['sales_14d']
                            if self._safe_float_or_none(value) is None
                        )
                    if missing_14d > 0:
                        result['warnings'].append(
                            f"{missing_14d} 个SKU标记为雨天但缺少14日销量,这些SKU将转人工审核"
                        )
            
            # 检查文件大小
            file_size = os.path.getsize(file_path)
            if file_size > 5 * 1024 * 1024:  # 5MB
                result['warnings'].append(f"文件较大({file_size / 1024 / 1024:.2f}MB),建议拆分处理")
            
        except Exception as e:
            result['valid'] = False
            result['errors'].append(f"文件解析失败: {str(e)}")
        
        return result


def main():
    """主函数 - 用内置样例模板跑通解析到建单的完整链路"""
    processor = ExcelProcessor()
    
    skill_root = os.path.dirname(os.path.dirname(__file__))
    upload_file = os.path.join(skill_root, 'templates', '补货计算数据样例.csv')
    
    if not os.path.exists(upload_file):
        print(f"样例文件不存在: {upload_file}")
        return
    
    # 验证格式
    validation = processor.validate_excel_format(upload_file)
    print(f"文件验证: {'通过' if validation['valid'] else '失败'}")
    print(f"SKU数量: {validation['sku_count']}")
    for warning in validation['warnings']:
        print(f"  警告: {warning}")
    for error in validation['errors']:
        print(f"  错误: {error}")
    
    if not validation['valid']:
        return
    
    # 解析数据
    sku_list = processor.parse_upload_excel(upload_file)
    print(f"成功解析 {len(sku_list)} 个SKU")
    
    # 计算补货量(从 config/ 目录加载参数)
    # 显式加入脚本目录,兼容未将其自动置入sys.path的Python环境
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from calculate_replenishment import ReplenishmentCalculator
    config_dir = os.path.join(skill_root, 'config')
    calculator = ReplenishmentCalculator(config_dir if os.path.isdir(config_dir) else None)
    results = calculator.batch_calculate(sku_list)
    
    # 异常汇总
    summary = calculator.check_anomalies(results)
    print(f"可自动建单 {summary['auto_order_count']} 个, "
          f"需人工审核 {summary['need_review_count']} 个")
    
    # 生成建单模板
    try:
        output_dir = os.path.join(os.getcwd(), 'output')
        os.makedirs(output_dir, exist_ok=True)
        processor.generate_purchase_template(
            results, os.path.join(output_dir, 'purchase_template.xlsx')
        )
    except ImportError:
        print("跳过Excel导出: 缺少 openpyxl,可执行 pip install -r requirements.txt 后重试")


if __name__ == '__main__':
    main()
