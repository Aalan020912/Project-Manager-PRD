#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置参数验证脚本
验证所有配置文件的格式和有效性
"""

import json
import os
import sys
from typing import Dict, List, Tuple

# 兼容非UTF-8终端(如Windows中文环境的GBK),避免输出时抛 UnicodeEncodeError
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(errors='replace')
    except (ValueError, OSError):
        pass


class ConfigValidator:
    """配置验证器"""
    
    def __init__(self, config_dir: str = None):
        """
        初始化验证器
        
        Args:
            config_dir: 配置文件目录路径
        """
        if config_dir is None:
            # 默认为skills目录下的config
            config_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)),
                'config'
            )
        self.config_dir = config_dir
        self.errors = []
        self.warnings = []
    
    def validate_all(self) -> Tuple[bool, List[str], List[str]]:
        """
        验证所有配置文件
        
        Returns:
            (是否全部通过, 错误列表, 警告列表)
        """
        print(f"开始验证配置文件: {self.config_dir}\n")
        
        # 获取所有配置文件
        config_files = [f for f in os.listdir(self.config_dir) if f.endswith('.json')]
        
        if not config_files:
            self.errors.append("未找到任何配置文件")
            return False, self.errors, self.warnings
        
        # 验证每个配置文件
        for config_file in config_files:
            file_path = os.path.join(self.config_dir, config_file)
            self._validate_single_config(file_path)
        
        # 验证权重配置
        self._validate_weights()
        
        # 输出结果
        print("\n" + "="*50)
        if self.errors:
            print("[FAIL] 验证失败!")
            for error in self.errors:
                print(f"  错误: {error}")
        else:
            print("[OK] 验证通过!")
        
        if self.warnings:
            print("\n[WARN] 警告:")
            for warning in self.warnings:
                print(f"  {warning}")
        
        print("="*50)
        
        return len(self.errors) == 0, self.errors, self.warnings
    
    def _validate_single_config(self, file_path: str):
        """验证单个配置文件"""
        config_file = os.path.basename(file_path)
        print(f"验证: {config_file}")
        
        try:
            # 读取JSON文件
            with open(file_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 检查必需字段
            required_fields = [
                'parameterName',
                'displayName',
                'description',
                'type',
                'value',
                'businessMeaning'
            ]
            
            for field in required_fields:
                if field not in config:
                    self.errors.append(f"{config_file}: 缺少必需字段 '{field}'")
            
            # 验证类型
            if 'type' in config:
                valid_types = ['string', 'number', 'boolean', 'array', 'object']
                if config['type'] not in valid_types:
                    self.errors.append(
                        f"{config_file}: 无效的类型 '{config['type']}', "
                        f"必须是: {', '.join(valid_types)}"
                    )
            
            # 验证数值类型
            if config.get('type') == 'number':
                if not isinstance(config.get('value'), (int, float)):
                    self.errors.append(
                        f"{config_file}: value应为数值类型,实际为 {type(config.get('value'))}"
                    )
            
            # 验证权重范围
            if '权重' in config_file:
                value = config.get('value', 0)
                if not (0 <= value <= 1):
                    self.errors.append(
                        f"{config_file}: 权重值 {value} 超出有效范围 [0, 1]"
                    )
            
            print(f"  [OK] {config.get('displayName', config_file)}")
            
        except json.JSONDecodeError as e:
            self.errors.append(f"{config_file}: JSON格式错误 - {str(e)}")
            print(f"  [FAIL] JSON格式错误")
        except Exception as e:
            self.errors.append(f"{config_file}: 读取失败 - {str(e)}")
            print(f"  [FAIL] 读取失败")
    
    def _validate_weights(self):
        """验证权重配置的总和"""
        print("\n验证权重配置...")
        
        weight_28d = None
        weight_7d = None
        
        # 读取权重配置
        for config_file in os.listdir(self.config_dir):
            if config_file.endswith('.json'):
                file_path = os.path.join(self.config_dir, config_file)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        config = json.load(f)
                    
                    if '28日销量权重' in config_file:
                        weight_28d = config.get('value')
                    elif '7日销量权重' in config_file:
                        weight_7d = config.get('value')
                except:
                    pass
        
        # 验证权重总和
        if weight_28d is not None and weight_7d is not None:
            total = weight_28d + weight_7d
            if abs(total - 1.0) > 0.01:
                self.errors.append(
                    f"权重总和必须为1,当前: {weight_28d} + {weight_7d} = {total}"
                )
            else:
                print(f"  [OK] 权重总和: {total}")
        else:
            self.warnings.append("未找到完整的权重配置")


def main():
    """主函数"""
    # 创建验证器
    validator = ConfigValidator()
    
    # 执行验证
    passed, errors, warnings = validator.validate_all()
    
    # 返回退出码
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
